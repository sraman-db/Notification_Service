package com.notificationservice.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.notificationservice.dto.NotificationRequest;
import com.notificationservice.dto.NotificationResponse;
import com.notificationservice.model.NotificationType;
import com.notificationservice.service.NotificationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(NotificationController.class)
public class NotificationControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private NotificationService notificationService;

    @Autowired
    private ObjectMapper objectMapper;

    private NotificationRequest notificationRequest;
    private NotificationResponse notificationResponse;
    private List<NotificationResponse> notificationResponses;

    @BeforeEach
    void setUp() {
        notificationRequest = NotificationRequest.builder()
                .userId(1L)
                .title("Test Notification")
                .message("This is a test notification")
                .type(NotificationType.EMAIL)
                .recipientEmail("test@example.com")
                .build();

        notificationResponse = NotificationResponse.builder()
                .id(1L)
                .userId(1L)
                .title("Test Notification")
                .message("This is a test notification")
                .type(NotificationType.EMAIL)
                .createdAt(LocalDateTime.now())
                .status("PENDING")
                .isRead(false)
                .build();

        notificationResponses = Arrays.asList(notificationResponse);
    }

    @Test
    void sendNotification_shouldReturnCreatedStatus() throws Exception {
        when(notificationService.createNotification(any(NotificationRequest.class)))
                .thenReturn(notificationResponse);

        mockMvc.perform(post("/api/notifications")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(notificationRequest)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(notificationResponse.getId()))
                .andExpect(jsonPath("$.userId").value(notificationResponse.getUserId()))
                .andExpect(jsonPath("$.title").value(notificationResponse.getTitle()))
                .andExpect(jsonPath("$.message").value(notificationResponse.getMessage()))
                .andExpect(jsonPath("$.type").value(notificationResponse.getType().toString()))
                .andExpect(jsonPath("$.status").value(notificationResponse.getStatus()));
    }

    @Test
    void getUserNotifications_shouldReturnOkStatus() throws Exception {
        Long userId = 1L;
        when(notificationService.getUserNotifications(userId))
                .thenReturn(notificationResponses);

        mockMvc.perform(get("/api/users/{userId}/notifications", userId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(notificationResponse.getId()))
                .andExpect(jsonPath("$[0].userId").value(notificationResponse.getUserId()))
                .andExpect(jsonPath("$[0].title").value(notificationResponse.getTitle()))
                .andExpect(jsonPath("$[0].message").value(notificationResponse.getMessage()))
                .andExpect(jsonPath("$[0].type").value(notificationResponse.getType().toString()))
                .andExpect(jsonPath("$[0].status").value(notificationResponse.getStatus()));
    }
}
