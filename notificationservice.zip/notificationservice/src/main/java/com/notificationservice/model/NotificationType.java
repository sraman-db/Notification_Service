package com.notificationservice.model;

public enum NotificationType {
    EMAIL,
    SMS,
    IN_APP
}