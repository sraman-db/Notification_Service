package com.notificationservice.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "notifications")
public class Notification {
    
    @Id
    private String id;
    
    private Long userId;
    private String title;
    private String message;
    private NotificationType type;
    private String recipientEmail;
    private String recipientPhone;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private String status;
    private boolean isRead;
    private int retryCount;
}
