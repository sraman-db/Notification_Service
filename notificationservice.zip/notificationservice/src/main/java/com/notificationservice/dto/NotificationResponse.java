package com.notificationservice.dto;

import java.time.LocalDateTime;

import com.notificationservice.model.NotificationType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class NotificationResponse {
    
    private String id;
    private Long userId;
    private String title;
    private String message;
    private NotificationType type;
    private LocalDateTime createdAt;
    private String status;
    private boolean isRead;
}