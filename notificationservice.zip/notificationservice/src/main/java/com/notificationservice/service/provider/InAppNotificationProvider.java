package com.notificationservice.service.provider;

import com.notificationservice.model.Notification;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class InAppNotificationProvider {

    @Value("${notification.inapp.enabled:true}")
    private boolean inAppEnabled;

    public boolean send(Notification notification) {
        if (!inAppEnabled) {
            log.info("In-app notifications are disabled");
            return false;
        }

        if (notification.getUserId() == null) {
            log.error("Cannot send in-app notification: userId is null");
            return false;
        }

        try {
            // In a real implementation, this might store the notification in a database
            // or push it to a real-time messaging system like WebSockets
            log.info("Sending in-app notification to user: {}", notification.getUserId());
            log.info("Notification title: {}", notification.getTitle());
            log.info("Notification message: {}", notification.getMessage());
            
            // Simulate sending in-app notification
            // In production, implement actual in-app delivery logic here
            
            return true;
        } catch (Exception e) {
            log.error("Failed to send in-app notification", e);
            return false;
        }
    }
}