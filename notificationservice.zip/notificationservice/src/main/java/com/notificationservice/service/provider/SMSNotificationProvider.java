package com.notificationservice.service.provider;

import com.notificationservice.model.Notification;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class SMSNotificationProvider {

    @Value("${notification.sms.enabled:true}")
    private boolean smsEnabled;

    public boolean send(Notification notification) {
        if (!smsEnabled) {
            log.info("SMS notifications are disabled");
            return false;
        }

        if (notification.getRecipientPhone() == null || notification.getRecipientPhone().isEmpty()) {
            log.error("Cannot send SMS notification: recipient phone number is empty");
            return false;
        }

        try {
            // In a real implementation, this would connect to an SMS service
            // like Twilio, AWS SNS, etc.
            log.info("Sending SMS notification to: {}", notification.getRecipientPhone());
            log.info("SMS content: {}", notification.getMessage());
            
            // Simulate sending SMS
            // In production, implement actual SMS sending logic here
            
            return true;
        } catch (Exception e) {
            log.error("Failed to send SMS notification", e);
            return false;
        }
    }
}