package com.notificationservice.service;

import com.notificationservice.dto.NotificationRequest;
import com.notificationservice.dto.NotificationResponse;
import com.notificationservice.model.Notification;
import com.notificationservice.model.NotificationType;
import com.notificationservice.queue.NotificationProducer;
import com.notificationservice.repository.NotificationRepository;
import com.notificationservice.service.impl.NotificationServiceImpl;
import com.notificationservice.service.provider.EmailNotificationProvider;
import com.notificationservice.service.provider.InAppNotificationProvider;
import com.notificationservice.service.provider.SMSNotificationProvider;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class NotificationServiceTest {

    @Mock
    private NotificationRepository notificationRepository;

    @Mock
    private NotificationProducer notificationProducer;

    @Mock
    private EmailNotificationProvider emailNotificationProvider;

    @Mock
    private SMSNotificationProvider smsNotificationProvider;

    @Mock
    private InAppNotificationProvider inAppNotificationProvider;

    @InjectMocks
    private NotificationServiceImpl notificationService;

    private NotificationRequest notificationRequest;
    private Notification notification;
    private List<Notification> notifications;

    @BeforeEach
    void setUp() {
        notificationRequest = NotificationRequest.builder()
                .userId(1L)
                .title("Test Notification")
                .message("This is a test notification")
                .type(NotificationType.EMAIL)
                .recipientEmail("test@example.com")
                .build();

        notification = Notification.builder()
                .id(1L)
                .userId(1L)
                .title("Test Notification")
                .message("This is a test notification")
                .type(NotificationType.EMAIL)
                .createdAt(LocalDateTime.now())
                .isRead(false)
                .retryCount(0)
                .status("PENDING")
                .build();

        notifications = Arrays.asList(notification);
    }

    @Test
    void createNotification_shouldSaveAndSendToQueue() {
        when(notificationRepository.save(any(Notification.class))).thenReturn(notification);
        doNothing().when(notificationProducer).sendNotification(any(Notification.class));

        NotificationResponse response = notificationService.createNotification(notificationRequest);

        assertEquals(notification.getId(), response.getId());
        assertEquals(notification.getUserId(), response.getUserId());
        assertEquals(notification.getTitle(), response.getTitle());
        assertEquals(notification.getMessage(), response.getMessage());
        assertEquals(notification.getType(), response.getType());
        assertEquals(notification.getStatus(), response.getStatus());

        verify(notificationRepository, times(1)).save(any(Notification.class));
        verify(notificationProducer, times(1)).sendNotification(any(Notification.class));
    }

    @Test
    void getUserNotifications_shouldReturnUserNotifications() {
        when(notificationRepository.findByUserIdOrderByCreatedAtDesc(anyLong())).thenReturn(notifications);

        List<NotificationResponse> responses = notificationService.getUserNotifications(1L);

        assertEquals(1, responses.size());
        assertEquals(notification.getId(), responses.get(0).getId());
        assertEquals(notification.getUserId(), responses.get(0).getUserId());
        assertEquals(notification.getTitle(), responses.get(0).getTitle());
        assertEquals(notification.getMessage(), responses.get(0).getMessage());
        assertEquals(notification.getType(), responses.get(0).getType());

        verify(notificationRepository, times(1)).findByUserIdOrderByCreatedAtDesc(anyLong());
    }

    @Test
    void processNotification_shouldProcessEmailNotification() {
        when(emailNotificationProvider.send(any(Notification.class))).thenReturn(true);
        when(notificationRepository.save(any(Notification.class))).thenReturn(notification);

        boolean result = notificationService.processNotification(notification);

        assertTrue(result);
        assertEquals("SENT", notification.getStatus());
        verify(emailNotificationProvider, times(1)).send(any(Notification.class));
        verify(notificationRepository, times(1)).save(any(Notification.class));
    }

    @Test
    void retryFailedNotifications_shouldRetryFailedNotifications() {
        when(notificationRepository.findByStatusAndRetryCountLessThan(anyString(), anyInt()))
                .thenReturn(notifications);
        doNothing().when(notificationProducer).sendNotification(any(Notification.class));

        notificationService.retryFailedNotifications();

        verify(notificationRepository, times(1)).findByStatusAndRetryCountLessThan(anyString(), anyInt());
        verify(notificationProducer, times(1)).sendNotification(any(Notification.class));
    }
}
