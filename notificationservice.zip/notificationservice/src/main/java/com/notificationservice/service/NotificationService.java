package com.notificationservice.service;

import com.notificationservice.dto.NotificationRequest;
import com.notificationservice.dto.NotificationResponse;
import com.notificationservice.model.Notification;

import java.util.List;

public interface NotificationService {
    
    NotificationResponse createNotification(NotificationRequest request);
    
    List<NotificationResponse> getUserNotifications(Long userId);
    
    boolean processNotification(Notification notification);
    
    void updateNotification(Notification notification);
    
    void retryFailedNotifications();
}
