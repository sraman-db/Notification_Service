package com.notificationservice.service.impl;

import com.notificationservice.dto.NotificationRequest;
import com.notificationservice.dto.NotificationResponse;
import com.notificationservice.model.Notification;
import com.notificationservice.model.NotificationType;
import com.notificationservice.queue.NotificationProducer;
import com.notificationservice.repository.NotificationRepository;
import com.notificationservice.service.NotificationService;
import com.notificationservice.service.provider.EmailNotificationProvider;
import com.notificationservice.service.provider.InAppNotificationProvider;
import com.notificationservice.service.provider.SMSNotificationProvider;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
public class NotificationServiceImpl implements NotificationService {

    private final NotificationRepository notificationRepository;
    private final NotificationProducer notificationProducer;
    private final EmailNotificationProvider emailNotificationProvider;
    private final SMSNotificationProvider smsNotificationProvider;
    private final InAppNotificationProvider inAppNotificationProvider;

    @Value("${notification.retry.max-attempts}")
    private int maxRetryAttempts;

    public NotificationServiceImpl(NotificationRepository notificationRepository,
                                   NotificationProducer notificationProducer,
                                   EmailNotificationProvider emailNotificationProvider,
                                   SMSNotificationProvider smsNotificationProvider,
                                   InAppNotificationProvider inAppNotificationProvider) {
        this.notificationRepository = notificationRepository;
        this.notificationProducer = notificationProducer;
        this.emailNotificationProvider = emailNotificationProvider;
        this.smsNotificationProvider = smsNotificationProvider;
        this.inAppNotificationProvider = inAppNotificationProvider;
    }

    @Override
    public NotificationResponse createNotification(NotificationRequest request) {
        Notification notification = Notification.builder()
                .userId(request.getUserId())
                .title(request.getTitle())
                .message(request.getMessage())
                .type(request.getType())
                .recipientEmail(request.getRecipientEmail())
                .recipientPhone(request.getRecipientPhone())
                .createdAt(LocalDateTime.now())
                .status("PENDING")
                .isRead(false)
                .retryCount(0)
                .build();

        notification = notificationRepository.save(notification);
        notificationProducer.sendNotification(notification);

        return convertToResponse(notification);
    }

    @Override
    public List<NotificationResponse> getUserNotifications(Long userId) {
        List<Notification> notifications = notificationRepository.findByUserIdOrderByCreatedAtDesc(userId);
        return notifications.stream()
                .map(this::convertToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public boolean processNotification(Notification notification) {
        boolean success = false;

        try {
            switch (notification.getType()) {
                case EMAIL:
                    success = emailNotificationProvider.send(notification);
                    break;
                case SMS:
                    success = smsNotificationProvider.send(notification);
                    break;
                case IN_APP:
                    success = inAppNotificationProvider.send(notification);
                    break;
                default:
                    log.warn("Unsupported notification type: {}", notification.getType());
            }

            if (success) {
                notification.setStatus("SENT");
                notification.setUpdatedAt(LocalDateTime.now());
            } else {
                notification.setStatus("FAILED");
                notification.setRetryCount(notification.getRetryCount() + 1);
            }

            notificationRepository.save(notification);
            return success;
        } catch (Exception e) {
            log.error("Error processing notification: {}", notification.getId(), e);
            notification.setStatus("FAILED");
            notification.setRetryCount(notification.getRetryCount() + 1);
            notificationRepository.save(notification);
            return false;
        }
    }

    @Override
    public void updateNotification(Notification notification) {
        notification.setUpdatedAt(LocalDateTime.now());
        notificationRepository.save(notification);
    }

    @Override
    public void retryFailedNotifications() {
        List<Notification> failedNotifications = notificationRepository.findByStatusAndRetryCountLessThan(
                "FAILED", maxRetryAttempts);

        for (Notification notification : failedNotifications) {
            log.info("Retrying failed notification: {}", notification.getId());
            notificationProducer.sendNotification(notification);
        }
    }

    private NotificationResponse convertToResponse(Notification notification) {
        return NotificationResponse.builder()
                .id(notification.getId())
                .userId(notification.getUserId())
                .title(notification.getTitle())
                .message(notification.getMessage())
                .type(notification.getType())
                .createdAt(notification.getCreatedAt())
                .status(notification.getStatus())
                .isRead(notification.isRead())
                .build();
    }
}
