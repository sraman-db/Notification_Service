package com.notificationservice.service.provider;

import com.notificationservice.model.Notification;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class EmailNotificationProvider {

    @Value("${notification.email.enabled:true}")
    private boolean emailEnabled;

    public boolean send(Notification notification) {
        if (!emailEnabled) {
            log.info("Email notifications are disabled");
            return false;
        }

        if (notification.getRecipientEmail() == null || notification.getRecipientEmail().isEmpty()) {
            log.error("Cannot send email notification: recipient email is empty");
            return false;
        }

        try {
            // In a real implementation, this would connect to an email service
            // like SendGrid, AWS SES, or SMTP server
            log.info("Sending email notification to: {}", notification.getRecipientEmail());
            log.info("Email subject: {}", notification.getTitle());
            log.info("Email content: {}", notification.getMessage());
            
            // Simulate sending email
            // In production, implement actual email sending logic here
            
            return true;
        } catch (Exception e) {
            log.error("Failed to send email notification", e);
            return false;
        }
    }
}