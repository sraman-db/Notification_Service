package com.notificationservice.Queue;

import com.notificationservice.model.Notification;
import com.notificationservice.service.NotificationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Component;

@Component
public class NotificationConsumer {
    private static final Logger logger = LoggerFactory.getLogger(NotificationConsumer.class);

    private final NotificationService notificationService;
    private final RetryTemplate retryTemplate;

    @Autowired
    public NotificationConsumer(NotificationService notificationService, RetryTemplate retryTemplate) {
        this.notificationService = notificationService;
        this.retryTemplate = retryTemplate;
    }

    @RabbitListener(queues = "${rabbitmq.queue.name:notification-queue}")
    public void consumeNotification(Notification notification) {
        logger.info("Received notification from queue: {}", notification.getId());
        
        try {
            boolean success = notificationService.processNotification(notification);
            logger.info("Notification processing {} for ID: {}", success ? "succeeded" : "failed", notification.getId());
        } catch (Exception e) {
            logger.error("Error processing notification: {}", e.getMessage());
        }
    }
}