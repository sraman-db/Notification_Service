package com.notificationservice.Queue;

import com.notificationservice.model.Notification;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class NotificationProducer {
    private static final Logger logger = LoggerFactory.getLogger(NotificationProducer.class);

    private final RabbitTemplate rabbitTemplate;
    
    @Value("${rabbitmq.exchange.name:notification-exchange}")
    private String exchangeName;
    
    @Value("${rabbitmq.routing.key:notification-routing-key}")
    private String routingKey;

    @Autowired
    public NotificationProducer(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    public void sendNotification(Notification notification) {
        try {
            logger.info("Sending notification to queue: {}", notification.getId());
            rabbitTemplate.convertAndSend(exchangeName, routingKey, notification);
        } catch (Exception e) {
            logger.error("Error sending notification to queue: {}", e.getMessage());
        }
    }
}