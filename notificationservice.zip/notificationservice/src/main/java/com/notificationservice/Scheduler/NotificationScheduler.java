package com.notificationservice.Scheduler;

import com.notificationservice.service.NotificationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class NotificationScheduler {

    private final NotificationService notificationService;

    @Autowired
    public NotificationScheduler(NotificationService notificationService) {
        this.notificationService = notificationService;
    }

    @Scheduled(fixedDelayString = "${notification.retry.interval:300000}")
    public void retryFailedNotifications() {
        log.info("Starting scheduled task: retry failed notifications");
        notificationService.retryFailedNotifications();
        log.info("Completed scheduled task: retry failed notifications");
    }
}